# Research Project Page Template

A responsive research project page with a shared PDF viewer and a copyable citation.

1. Edit `index.html`: replace the title, authors, affiliations, resource links, text, BibTeX, and the `og:` link-preview tags.
2. Replace `assets/images/project-template-overview.svg`, `files/arxiv-template-example.pdf`, and its first-page preview `assets/images/arxiv-template-preview.svg` (shown on phones that cannot display PDFs inline).
3. Fonts are Crimson Pro and Inter (SIL Open Font License), bundled in `assets/fonts/`. Change the accent color with `--project-accent` on `<body>`; hover, soft, and dark-mode shades follow. Adjust spacing in `assets/css/project.css`.
4. Preview with `python -m http.server 8000`, then open http://localhost:8000/.
5. Remove the `noindex, nofollow` meta tag when ready to publish. Upload the folder to any static host.

This is a static HTML/CSS/JS template. No build step or framework is required.
The PDF stays vector-based and uses the browser's built-in viewer; the Open link works when embedding is unavailable.

The PDF viewer's canonical Jekyll source is `_includes/pdf-viewer.html` with `_sass/editorial/_pdf-viewer.scss` in the website repository. The export uses that same component, with its styles compiled into project.css.

MIT licensed. The bundled PDF is a sample from https://github.com/xzAscC/arxiv-template.
The Ohio State University logo in that sample is excluded from the license; replace the PDF before publishing your own project.
